<?php 
$produto = new StdClass; 
$produto->descricao = 'Chocolate Amargo'; 
$produto->estoque   = 100; 
$produto->preco     = 7; 

print_r($produto);